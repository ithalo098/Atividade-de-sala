import { useEffect, useMemo, useState } from 'react';
import './App.css';

function App() {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [loading, setLoading] = useState(true);
  const [usernameInput, setUsernameInput] = useState('');
  const [user, setUser] = useState(null);
  const [ranking, setRanking] = useState([]);
  const [error, setError] = useState('');
  const [savingScore, setSavingScore] = useState(false);

  useEffect(() => {
    fetch('/api/questions')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Falha ao buscar perguntas.');
        }

        return response.json();
      })
      .then((data) => {
        setQuestions(data);
        setLoading(false);
      })
      .catch((requestError) => {
        console.error('Erro ao buscar perguntas:', requestError);
        setError('Não foi possível carregar as perguntas.');
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    if (!user) {
      setRanking([]);
      return;
    }

    carregarRanking();
  }, [user?.username]);

  const scores = user?.scores ?? [];

  const historyStats = useMemo(() => {
    if (scores.length === 0) {
      return {
        totalGames: 0,
        bestScore: 0,
        averageScore: 0,
      };
    }

    const totalScore = scores.reduce((total, currentScore) => total + currentScore, 0);

    return {
      totalGames: scores.length,
      bestScore: Math.max(...scores),
      averageScore: (totalScore / scores.length).toFixed(1),
    };
  }, [scores]);

  const carregarRanking = () => {
    fetch('/api/ranking')
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Falha ao buscar ranking: ${response.status}`);
        }

        return response.json();
      })
      .then((data) => setRanking(data))
      .catch((requestError) => {
        console.error('Erro ao buscar ranking:', requestError);
      });
  };

  const handleLogin = (event) => {
    event.preventDefault();

    if (!usernameInput.trim()) return;

    setError('');

    fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: usernameInput }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Falha ao identificar usuário.');
        }

        return response.json();
      })
      .then((userData) => {
        setUser(userData);
      })
      .catch((requestError) => {
        console.error('Erro ao identificar usuário:', requestError);
        setError('Não foi possível entrar. Tente novamente.');
      });
  };

  const handleAnswerClick = (selectedOption) => {
    const currentQuestion = questions[currentQuestionIndex];
    let finalScore = score;

    if (selectedOption === currentQuestion.answer) {
      finalScore = score + 1;
      setScore(finalScore);
    }

    const nextQuestion = currentQuestionIndex + 1;

    if (nextQuestion < questions.length) {
      setCurrentQuestionIndex(nextQuestion);
      return;
    }

    setQuizFinished(true);
    enviarPontuacao(finalScore);
  };

  const enviarPontuacao = (finalScore) => {
    setSavingScore(true);
    setError('');

    fetch('/api/scores', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: user.username, score: finalScore }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Falha ao salvar pontuação.');
        }

        return response.json();
      })
      .then((data) => {
        setUser(data.updatedUser);
        carregarRanking();
      })
      .catch((requestError) => {
        console.error('Erro ao salvar pontuação:', requestError);
        setError('A partida terminou, mas a pontuação não pôde ser salva.');
      })
      .finally(() => {
        setSavingScore(false);
      });
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setScore(0);
    setQuizFinished(false);
    setError('');
  };

  const handleLogout = () => {
    setUser(null);
    setUsernameInput('');
    resetQuiz();
  };

  if (loading) {
    return (
      <div className="quiz-container">
        <div className="card loading-card">
          <h3>Carregando perguntas...</h3>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="quiz-container login-page">
        <h1>App de Quiz</h1>

        <div className="card login-card">
          <span className="eyebrow">Área do jogador</span>
          <h2>Seja bem-vindo!</h2>
          <p>Digite seu nome de usuário para jogar e consultar seu histórico.</p>

          <form onSubmit={handleLogin} className="login-form">
            <label htmlFor="username">Nome de usuário</label>
            <input
              id="username"
              type="text"
              placeholder="Ex.: alexandre"
              value={usernameInput}
              onChange={(event) => setUsernameInput(event.target.value)}
              autoComplete="username"
              required
            />
            <button type="submit" className="btn-reset">
              Entrar e jogar
            </button>
          </form>

          {error && <p className="error-message">{error}</p>}
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="quiz-container">
      <header className="user-bar">
        <div>
          <span className="user-bar-label">Jogador</span>
          <strong>{user.username}</strong>
        </div>
        <button type="button" onClick={handleLogout} className="btn-logout">
          Sair
        </button>
      </header>

      {error && <p className="error-message page-error">{error}</p>}

      <main className="app-layout">
        <section className="quiz-column">
          {quizFinished ? (
            <div className="card result-card">
              <span className="eyebrow">Resultado da rodada</span>
              <h2>Quiz concluído!</h2>
              <p className="result-score">
                Você acertou <strong>{score}</strong> de{' '}
                <strong>{questions.length}</strong> perguntas.
              </p>

              <div className="result-actions">
                <button
                  type="button"
                  onClick={resetQuiz}
                  className="btn-reset"
                  disabled={savingScore}
                >
                  {savingScore ? 'Salvando...' : 'Jogar novamente'}
                </button>
              </div>

              <div className="ranking-section">
                <h3>Ranking global</h3>
                <p className="section-description">
                  Melhores pontuações registradas pelos jogadores.
                </p>

                <div className="table-wrapper">
                  <table className="ranking-table">
                    <thead>
                      <tr>
                        <th>Posição</th>
                        <th>Jogador</th>
                        <th>Recorde</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ranking.length > 0 ? (
                        ranking.map((player, index) => (
                          <tr
                            key={player.username}
                            className={
                              player.username === user.username
                                ? 'current-player-row'
                                : ''
                            }
                          >
                            <td>{index + 1}º</td>
                            <td>
                              {player.username}{' '}
                              {player.username === user.username && '(você)'}
                            </td>
                            <td>{player.topScore} acertos</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="3">Ranking indisponível no momento.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="card quiz-card">
              <div className="quiz-header">
                <span>
                  Pergunta {currentQuestionIndex + 1} de {questions.length}
                </span>
                <span>Pontuação atual: {score}</span>
              </div>

              <div className="progress-track" aria-hidden="true">
                <div
                  className="progress-value"
                  style={{
                    width: `${((currentQuestionIndex + 1) / questions.length) * 100}%`,
                  }}
                />
              </div>

              <h2 className="question-text">{currentQuestion.question}</h2>

              <div className="options-container">
                {currentQuestion.options.map((option) => (
                  <button
                    type="button"
                    key={option}
                    onClick={() => handleAnswerClick(option)}
                    className="btn-option"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>

        <aside className="history-card card" aria-labelledby="history-title">
          <div className="history-heading">
            <div>
              <span className="eyebrow">Desempenho</span>
              <h2 id="history-title">Histórico do usuário</h2>
            </div>
            <span className="history-count">{historyStats.totalGames} partidas</span>
          </div>

          <div className="history-stats">
            <div className="stat-card">
              <span>Melhor resultado</span>
              <strong>{historyStats.bestScore}</strong>
            </div>
            <div className="stat-card">
              <span>Média</span>
              <strong>{historyStats.averageScore}</strong>
            </div>
          </div>

          {scores.length > 0 ? (
            <ol className="history-list">
              {[...scores].reverse().map((historicScore, reverseIndex) => {
                const originalIndex = scores.length - reverseIndex;

                return (
                  <li key={`${originalIndex}-${historicScore}`} className="history-item">
                    <div>
                      <strong>Partida {originalIndex}</strong>
                      <span>
                        {historicScore === historyStats.bestScore
                          ? 'Melhor pontuação'
                          : 'Pontuação registrada'}
                      </span>
                    </div>
                    <span className="history-score">
                      {historicScore}
                      <small> pts</small>
                    </span>
                  </li>
                );
              })}
            </ol>
          ) : (
            <div className="empty-history">
              <strong>Nenhuma partida registrada.</strong>
              <p>Conclua o quiz para adicionar sua primeira pontuação.</p>
            </div>
          )}
        </aside>
      </main>
    </div>
  );
}

export default App;
